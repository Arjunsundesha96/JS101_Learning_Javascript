//Problem 4: Given stored username and password and input username and password, Print if the user can login or not.


let user_name="Arjun kumar";
password="123456";
input_name="Arjun kumar";
input_password="123456";
if(input_name==user_name && input_password==password){
  console.log("login successful");
}else{
  console.log("incorrect input");
}