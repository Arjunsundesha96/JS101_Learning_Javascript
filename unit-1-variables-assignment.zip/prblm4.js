
let p="***************************************************************"


var x="                      𝙍𝙀𝙋𝙊𝙍𝙏  𝘾𝘼𝙍𝘿              "
let m="                🅼 🅰 🆂 🅰 🅸   🆂 🅲 🅷 🅾 🅾 🅻      "
console.log("");
console.log("");
console.log(p);
console.log("")
console.log(x);
console.log("");
console.log("");
console.log(m); 
console.log("");
console.log("");
var y="     N a m e        : 🅐 🅡 🅙 🅤 🅝 🅚 🅤 🅜 🅐 🅡 .🅢";
let z="     s e c t i o n  : 🅕 🅣 - 🅦 🅔 🅑 - ➋ ➋ "
var a="     R o l l N o.   : 🅕 🅦 ➋ ➋ _ ⓿ ➍ ➏ ➊";
var b="--------------------------------------------------------------";
var c="  𝙨𝙪𝙗𝙟𝙚𝙘𝙩      𝙢𝙖𝙧𝙠𝙨 𝙤𝙗𝙩        𝙢𝙖𝙭. 𝙢𝙖𝙧𝙠𝙨      𝙜𝙧𝙖𝙙𝙚 ";

var d="  js 101        7.5                10             B+";
var e="  DSA 101       8.0                10              A";
var f="  CC101         9.0                10              A+";
var g="--------------------------------------------------------------";
let h="  𝙛𝙞𝙣𝙖𝙡 𝙧𝙚𝙨𝙪𝙡𝙩   24.5              30               A ";
let i="---------------------------------------------------------------";
let j="**********   REMARK : PASS - Promoted to Next Unit   **********";
let k="  𝐀𝐧𝐤𝐢𝐭                                            𝙋𝙪𝙡𝙠𝙞𝙩 𝙏𝙮𝙖𝙜𝙞";
let l="Instructional                                      Instructor           Associate";
let q="***************************************************************"

console.log(y);
console.log("");
console.log(z);
console.log("");
console.log(a);
console.log("");
console.log(b);
console.log(c);
console.log("");
console.log(d);
console.log("");
console.log("");
console.log(e);
console.log("");
console.log(f);
console.log("");
console.log(g);
console.log(h);
console.log(i);
console.log("");
console.log("");
console.log(j);
console.log("");
console.log("");
console.log("");
console.log(k);
console.log(l);
console.log("");
console.log(q);