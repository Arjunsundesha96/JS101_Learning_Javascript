//Problem 4: Given 3 numbers (all different values), print which is greatest

let a=9;
b=8;
c=12;
if(a>b && a>c){
  console.log(a,"i greater");
}
if(a<b && b>c){
  console.log(b,"i greater");
}
else{
  console.log(c,"is greater");
}