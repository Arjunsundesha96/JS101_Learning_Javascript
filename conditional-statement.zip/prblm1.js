//Problem 1: If the number is divisible by 3, print a "multiple of 3".

let s = 15;
if (s % 3 == 0) {
  console.log("multiple of 3");
}

