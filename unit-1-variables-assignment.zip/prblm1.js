let a="Masai school";
let b="A Transformation in Education";
console.log(a);
console.log(b);
