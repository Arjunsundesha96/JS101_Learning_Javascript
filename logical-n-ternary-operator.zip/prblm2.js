//Problem 2 : Given any character, if it is a vowel print "Vowel"



let char="a";
(char=="a" ||char=="e" ||char=="i" ||char=="o" ||char=="u")?console.log("vowel"):console.log("not vowel");