//Problem 2: If a person is allowed to drive in India print "Apply for a license" or "NA".

let legal_age=18;
person_age=23;
if(person_age>=legal_age){
  console.log("Apply for a license");
}
else{
  console.log("NA");
}