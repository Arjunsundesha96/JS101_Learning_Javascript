//Problem 3
//Create a variable name to store your name
//Create a variable age to store your age
//Print the values stored in the variable on one line followed by the type of the variable in the next line

let name="Arjun";
const age=22;
console.log(name);
console.log(typeof(name));
console.log(age);
console.log(typeof(age));